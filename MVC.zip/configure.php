<?php  
        
         error_reporting(E_ALL);

         DEFINE('HOST','localhost');
         DEFINE('USERNAME','root');
         DEFINE('PASSWORD','root');
         DEFINE('DBNAME','CI'); 
          
?>