                  <div class="footer">
                           <p class="footer_msg">Copyright message. All right reserved.</p>
                  </div>

         </body>
</html>
