<?php

require_once __DIR__ . './../configure.php';

class Database {
         
         public $connection;
          
         function __construct() {
                  $this->connection = mysqli_connect(HOST,USERNAME,PASSWORD,DBNAME) or die("connection error"); 
         }
         
         public function insertRecord($data) { 
                  $query = "INSERT register set " . $data;   
                  $results = mysqli_query($this->connection, $query);
                  print_r($results);
         }
}